/* See LICENSE file for copyright and license details.
 *
 * pauzer - a work/break timer for dwm.
 *
 * The daemon counts down a work interval and freezes the countdown while
 * keyboard and mouse are idle (XScreenSaver extension), so time spent away
 * from the desk is never counted as work.  When the interval is over every
 * monitor is covered by a fullscreen overlay with a countdown and a
 * stretching hint, and the keyboard is grabbed so that typing does not leak
 * into the windows below.  The current state is written to a file for the
 * dwm status script, and the running daemon is driven by signals.
 */
#include <errno.h>
#include <locale.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/select.h>
#include <sys/types.h>

#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/Xft/Xft.h>
#include <X11/extensions/scrnsaver.h>
#ifdef XINERAMA
#include <X11/extensions/Xinerama.h>
#endif /* XINERAMA */

#define LEN(X)  (sizeof (X) / sizeof *(X))

typedef struct {
	const char *name;       /* what to do */
	const char *how;        /* how to do it, wrapped to the screen width */
} Tip;

typedef struct {
	Window win;
	Pixmap pm;              /* drawn into, then copied: no flicker */
	XftDraw *draw;
	int x, y, w, h;
} Overlay;

enum { StWork, StBreak, StOff };

#include "config.h"

static Display *dpy;
static int screen;
static Window root;
static Visual *visual;
static Colormap cmap;
static int depth, sw, sh;
static GC gc;
static Atom netwmopacity;
static XftFont *fnbig, *fnmid, *fnsmall;
static XftColor cfg, caccent, cmuted, cbg;
static Overlay *ovl;
static int novl;
static int grabbed;

static int havess;                      /* XScreenSaver extension usable */
static XScreenSaverInfo *ssinfo;

static int state = StWork;
static int remaining;                   /* seconds left in the current state */
static int frozen;                      /* work countdown frozen: user is away */
static int warned;                      /* pre-break warning already fired */
static int offremaining;                /* work seconds kept while switched off */
static const Tip *tip;
static int tipidx;
static char laststatus[256];

static volatile sig_atomic_t sigbreak, sigtoggle, sigreset, sigend;

static void
die(const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	va_end(ap);
	fputc('\n', stderr);
	exit(1);
}

static void
spawncmd(const char *cmd)
{
	if (!cmd || !*cmd)
		return;
	if (fork() == 0) {
		if (dpy)
			close(ConnectionNumber(dpy));
		setsid();
		execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
		_exit(127);
	}
}

/* seconds since the last keyboard or mouse event */
static int
idleseconds(void)
{
	if (!havess)
		return 0;
	if (!XScreenSaverQueryInfo(dpy, root, ssinfo))
		return 0;
	return (int)(ssinfo->idle / 1000);
}

static void
writestatus(void)
{
	char buf[256], tmp[256];
	FILE *f;
	int m;

	switch (state) {
	case StBreak:
		snprintf(buf, sizeof buf, statusbreak, remaining / 60, remaining % 60);
		break;
	case StOff:
		snprintf(buf, sizeof buf, "%s", statusoff);
		break;
	default:
		m = (remaining + 59) / 60;
		snprintf(buf, sizeof buf, frozen ? statusfrozen : statuswork, m);
		break;
	}
	if (!strcmp(buf, laststatus))
		return;
	snprintf(laststatus, sizeof laststatus, "%s", buf);

	snprintf(tmp, sizeof tmp, "%s.new", statusfile);
	if ((f = fopen(tmp, "w"))) {
		fprintf(f, "%s", buf);
		fclose(f);
		rename(tmp, statusfile);
	}
	/* only nudge the bar for the coarse states, not once a second */
	if (state != StBreak)
		spawncmd(cmdbarrefresh);
}

static void
drawcentered(Overlay *o, XftFont *fn, XftColor *col, int baseline, const char *text)
{
	XGlyphInfo ext;

	XftTextExtentsUtf8(dpy, fn, (FcChar8 *)text, strlen(text), &ext);
	XftDrawStringUtf8(o->draw, col, fn, (o->w - ext.xOff) / 2, baseline,
	                  (FcChar8 *)text, strlen(text));
}

/* draw text centered and wrapped to maxw, return the baseline below the last line */
static int
drawwrapped(Overlay *o, XftFont *fn, XftColor *col, int baseline, int maxw, const char *text)
{
	char buf[1024], line[1024];
	char *word, *save;
	XGlyphInfo ext;
	size_t prev, wl;

	snprintf(buf, sizeof buf, "%s", text);
	line[0] = '\0';
	for (word = strtok_r(buf, " ", &save); word; word = strtok_r(NULL, " ", &save)) {
		prev = strlen(line);
		wl = strlen(word);
		if (prev + wl + 2 > sizeof line)
			break;
		if (prev) {
			line[prev] = ' ';
			memcpy(line + prev + 1, word, wl + 1);
		} else {
			memcpy(line, word, wl + 1);
		}
		XftTextExtentsUtf8(dpy, fn, (FcChar8 *)line, strlen(line), &ext);
		if (ext.xOff <= maxw || !prev)
			continue;       /* fits, or a lone word wider than maxw */
		line[prev] = '\0'; /* too wide: flush all but the last word */
		drawcentered(o, fn, col, baseline, line);
		baseline += fn->height;
		memmove(line, word, wl + 1);
	}
	if (*line) {
		drawcentered(o, fn, col, baseline, line);
		baseline += fn->height;
	}
	return baseline;
}

static void
drawoverlay(Overlay *o)
{
	char buf[32];
	int y, by, done;

	XSetForeground(dpy, gc, cbg.pixel);
	XFillRectangle(dpy, o->pm, gc, 0, 0, o->w, o->h);

	y = o->h * 2 / 5 - fnbig->height / 2;
	drawcentered(o, fnmid, &cmuted, y - fnmid->height, breaktitle);

	snprintf(buf, sizeof buf, "%d:%02d", remaining / 60, remaining % 60);
	drawcentered(o, fnbig, &caccent, y + fnbig->ascent, buf);

	/* progress of the break */
	by = y + fnbig->height + fnmid->height;
	done = breaktime > 0 ? (breaktime - remaining) * barwidth / breaktime : barwidth;
	XSetForeground(dpy, gc, cmuted.pixel);
	XFillRectangle(dpy, o->pm, gc, (o->w - barwidth) / 2, by, barwidth, barheight);
	XSetForeground(dpy, gc, caccent.pixel);
	XFillRectangle(dpy, o->pm, gc, (o->w - barwidth) / 2, by, done, barheight);

	y = by + barheight + fnmid->height + fnmid->ascent;
	drawcentered(o, fnmid, &caccent, y, tip->name);
	y += fnmid->height / 2;
	drawwrapped(o, fnsmall, &cfg, y + fnsmall->height, o->w * 3 / 4, tip->how);

	drawcentered(o, fnsmall, &cmuted, o->h - fnsmall->descent - fnsmall->height / 2,
	             breakhint);

	XCopyArea(dpy, o->pm, o->win, gc, 0, 0, o->w, o->h, 0, 0);
	XRaiseWindow(dpy, o->win);
}

static void
createoverlays(void)
{
	XSetWindowAttributes wa;
	XClassHint ch = { "pauzer", "pauzer" };
	unsigned long op;
	int i, n = 1;
#ifdef XINERAMA
	XineramaScreenInfo *info = NULL;

	if (XineramaIsActive(dpy) && (info = XineramaQueryScreens(dpy, &n)) == NULL)
		n = 1;
#endif /* XINERAMA */
	if (!(ovl = calloc(n, sizeof *ovl)))
		die("pauzer: cannot allocate overlays");
	novl = n;

	for (i = 0; i < n; i++) {
#ifdef XINERAMA
		if (info) {
			ovl[i].x = info[i].x_org;
			ovl[i].y = info[i].y_org;
			ovl[i].w = info[i].width;
			ovl[i].h = info[i].height;
		} else
#endif /* XINERAMA */
		{
			ovl[i].x = ovl[i].y = 0;
			ovl[i].w = sw;
			ovl[i].h = sh;
		}
		wa.override_redirect = True;
		wa.background_pixel = cbg.pixel;
		wa.event_mask = ExposureMask | KeyPressMask | ButtonPressMask;
		wa.save_under = True;
		ovl[i].win = XCreateWindow(dpy, root, ovl[i].x, ovl[i].y, ovl[i].w, ovl[i].h,
		                           0, depth, CopyFromParent, visual,
		                           CWOverrideRedirect | CWBackPixel | CWEventMask |
		                           CWSaveUnder, &wa);
		ovl[i].pm = XCreatePixmap(dpy, root, ovl[i].w, ovl[i].h, depth);
		XSetClassHint(dpy, ovl[i].win, &ch);
		XStoreName(dpy, ovl[i].win, "pauzer");
		op = (unsigned long)(0xffffffffU * (opacity < 0 ? 0 : opacity > 1 ? 1 : opacity));
		XChangeProperty(dpy, ovl[i].win, netwmopacity, XA_CARDINAL, 32,
		                PropModeReplace, (unsigned char *)&op, 1);
		ovl[i].draw = XftDrawCreate(dpy, ovl[i].pm, visual, cmap);
		XMapRaised(dpy, ovl[i].win);
	}
#ifdef XINERAMA
	if (info)
		XFree(info);
#endif /* XINERAMA */

	/* grab the keyboard the way slock does, the WM may still hold it */
	for (i = 0; i < 100; i++) {
		if (XGrabKeyboard(dpy, ovl[0].win, True, GrabModeAsync, GrabModeAsync,
		                  CurrentTime) == GrabSuccess) {
			grabbed = 1;
			break;
		}
		nanosleep(&(struct timespec){ 0, 10000000 }, NULL);
	}
	for (i = 0; i < novl; i++)
		drawoverlay(&ovl[i]);
	XFlush(dpy);
}

static void
destroyoverlays(void)
{
	int i;

	if (grabbed) {
		XUngrabKeyboard(dpy, CurrentTime);
		grabbed = 0;
	}
	for (i = 0; i < novl; i++) {
		XftDrawDestroy(ovl[i].draw);
		XFreePixmap(dpy, ovl[i].pm);
		XDestroyWindow(dpy, ovl[i].win);
	}
	free(ovl);
	ovl = NULL;
	novl = 0;
	XFlush(dpy);
}

static void
startbreak(void)
{
	if (state == StBreak)
		return;
	state = StBreak;
	remaining = breaktime;
	warned = 0;
	tip = &tips[tipidx];
	tipidx = (tipidx + 1) % LEN(tips);
	createoverlays();
	spawncmd(cmdbreakstart);
	writestatus();
}

static void
endbreak(int completed)
{
	if (state == StBreak)
		destroyoverlays();
	state = StWork;
	remaining = worktime;
	frozen = warned = 0;
	if (completed)
		spawncmd(cmdbreakend);
	writestatus();
}

static void
postpone(void)
{
	if (state == StBreak)
		destroyoverlays();
	state = StWork;
	remaining = postponetime;
	frozen = warned = 0;
	writestatus();
}

static void
togglepause(void)
{
	if (state == StOff) {
		state = StWork;
		remaining = offremaining > 0 ? offremaining : worktime;
		frozen = warned = 0;
	} else {
		if (state == StBreak)
			destroyoverlays();
		offremaining = state == StWork ? remaining : worktime;
		state = StOff;
	}
	writestatus();
}

static void
keypress(XKeyEvent *e)
{
	KeySym ks = XLookupKeysym(e, 0);

	if (state != StBreak)
		return;
	switch (ks) {
	case XK_Escape:
	case XK_q:
		endbreak(0);
		break;
	case XK_p:
		postpone();
		break;
	}
}

static void
tick(int delta)
{
	int idle, i;

	if (state == StOff)
		return;

	if (state == StBreak) {
		remaining -= delta;
		if (remaining <= 0) {
			endbreak(1);
			return;
		}
		for (i = 0; i < novl; i++)
			drawoverlay(&ovl[i]);
		writestatus();
		return;
	}

	idle = idleseconds();
	if (idlecredit && idle >= breaktime) {
		/* away long enough, that already was a break */
		remaining = worktime;
		frozen = warned = 0;
	} else if (idle >= idlefreeze) {
		frozen = 1;
	} else {
		frozen = 0;
		remaining -= delta;
		if (!warned && remaining <= warntime) {
			warned = 1;
			spawncmd(cmdwarn);
		}
		if (remaining <= 0) {
			startbreak();
			return;
		}
	}
	writestatus();
}

static void
sighandler(int sig)
{
	switch (sig) {
	case SIGUSR1: sigtoggle = 1; break;
	case SIGUSR2: sigbreak = 1; break;
	case SIGHUP:  sigreset = 1; break;
	default:      sigend = 1;   break;
	}
}

static void
setup(void)
{
	int evbase, errbase, mjr, mnr;

	if (!(dpy = XOpenDisplay(NULL)))
		die("pauzer: cannot open display");
	screen = DefaultScreen(dpy);
	root = RootWindow(dpy, screen);
	visual = DefaultVisual(dpy, screen);
	cmap = DefaultColormap(dpy, screen);
	depth = DefaultDepth(dpy, screen);
	sw = DisplayWidth(dpy, screen);
	sh = DisplayHeight(dpy, screen);
	netwmopacity = XInternAtom(dpy, "_NET_WM_WINDOW_OPACITY", False);
	gc = XCreateGC(dpy, root, 0, NULL);

	if (!(fnbig = XftFontOpenName(dpy, screen, fontbig)) ||
	    !(fnmid = XftFontOpenName(dpy, screen, fontmid)) ||
	    !(fnsmall = XftFontOpenName(dpy, screen, fontsmall)))
		die("pauzer: cannot load fonts");
	if (!XftColorAllocName(dpy, visual, cmap, colfg, &cfg) ||
	    !XftColorAllocName(dpy, visual, cmap, colaccent, &caccent) ||
	    !XftColorAllocName(dpy, visual, cmap, colmuted, &cmuted) ||
	    !XftColorAllocName(dpy, visual, cmap, colbg, &cbg))
		die("pauzer: cannot allocate colors");

	havess = XScreenSaverQueryExtension(dpy, &evbase, &errbase) &&
	         XScreenSaverQueryVersion(dpy, &mjr, &mnr) &&
	         (ssinfo = XScreenSaverAllocInfo()) != NULL;
	if (!havess)
		fprintf(stderr, "pauzer: no XScreenSaver extension, idle detection off\n");
}

static void
cleanup(void)
{
	if (state == StBreak)
		destroyoverlays();
	unlink(statusfile);
	unlink(pidfile);
	spawncmd(cmdbarrefresh);
	XftFontClose(dpy, fnbig);
	XftFontClose(dpy, fnmid);
	XftFontClose(dpy, fnsmall);
	XFreeGC(dpy, gc);
	XCloseDisplay(dpy);
}

static void
run(void)
{
	struct timeval tv;
	time_t last, now;
	fd_set fds;
	XEvent ev;
	int fd, delta, i;

	fd = ConnectionNumber(dpy);
	last = time(NULL);
	while (!sigend) {
		FD_ZERO(&fds);
		FD_SET(fd, &fds);
		tv.tv_sec = 1;
		tv.tv_usec = 0;
		if (select(fd + 1, &fds, NULL, NULL, &tv) < 0 && errno != EINTR)
			die("pauzer: select failed");

		if (sigtoggle) { sigtoggle = 0; togglepause(); }
		if (sigbreak) { sigbreak = 0; if (state != StOff) startbreak(); }
		if (sigreset) { sigreset = 0; if (state == StBreak) endbreak(0);
		                else if (state == StWork) { remaining = worktime;
		                warned = 0; writestatus(); } }

		while (XPending(dpy)) {
			XNextEvent(dpy, &ev);
			if (ev.type == KeyPress)
				keypress(&ev.xkey);
			else if (ev.type == Expose)
				for (i = 0; i < novl; i++)
					drawoverlay(&ovl[i]);
		}

		now = time(NULL);
		delta = (int)(now - last);
		if (delta < 0)          /* clock jumped backwards */
			delta = 0;
		if (delta > 0) {
			last = now;
			tick(delta);
		}
	}
}

static pid_t
readpid(void)
{
	FILE *f;
	long pid = 0;

	if (!(f = fopen(pidfile, "r")))
		return 0;
	if (fscanf(f, "%ld", &pid) != 1)
		pid = 0;
	fclose(f);
	if (pid > 0 && kill((pid_t)pid, 0) == 0)
		return (pid_t)pid;
	return 0;
}

static void
sendsig(int sig)
{
	pid_t pid = readpid();

	if (!pid)
		die("pauzer: not running");
	if (kill(pid, sig) < 0)
		die("pauzer: cannot signal %ld: %s", (long)pid, strerror(errno));
}

static void
printstatus(void)
{
	char buf[256];
	FILE *f;

	if ((f = fopen(statusfile, "r"))) {
		if (fgets(buf, sizeof buf, f))
			printf("%s\n", buf);
		fclose(f);
	}
}

static void
usage(void)
{
	die("usage: pauzer [-bprsv]\n"
	    "  (none)  run the daemon\n"
	    "  -b      start a break now\n"
	    "  -p      pause or resume the timer\n"
	    "  -r      restart the work interval\n"
	    "  -s      print the current status line\n"
	    "  -v      print version");
}

int
main(int argc, char *argv[])
{
	FILE *f;

	if (argc > 2)
		usage();
	if (argc == 2) {
		if (!strcmp(argv[1], "-v"))
			{ puts("pauzer-"VERSION); return 0; }
		else if (!strcmp(argv[1], "-b"))
			sendsig(SIGUSR2);
		else if (!strcmp(argv[1], "-p"))
			sendsig(SIGUSR1);
		else if (!strcmp(argv[1], "-r"))
			sendsig(SIGHUP);
		else if (!strcmp(argv[1], "-s"))
			printstatus();
		else
			usage();
		return 0;
	}

	if (readpid())
		die("pauzer: already running");

	setlocale(LC_ALL, "");
	srand((unsigned)time(NULL) ^ (unsigned)getpid());
	tipidx = rand() % LEN(tips);   /* start somewhere in the cycle */
	setup();

	if ((f = fopen(pidfile, "w"))) {
		fprintf(f, "%ld\n", (long)getpid());
		fclose(f);
	}

	signal(SIGCHLD, SIG_IGN);       /* no zombies from spawncmd */
	signal(SIGUSR1, sighandler);
	signal(SIGUSR2, sighandler);
	signal(SIGHUP, sighandler);
	signal(SIGTERM, sighandler);
	signal(SIGINT, sighandler);

	state = StWork;
	remaining = worktime;
	writestatus();
	run();
	cleanup();
	return 0;
}
