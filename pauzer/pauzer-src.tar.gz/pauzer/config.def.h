/* See LICENSE file for copyright and license details. */

/* timing (seconds) */
static const int worktime    = 40 * 60; /* length of a work interval */
static const int breaktime   =  5 * 60; /* length of a break */
static const int postponetime=  5 * 60; /* "later" pushes the break this far */
static const int warntime    =       60; /* warn this long before a break */
static const int idlefreeze  =  2 * 60; /* freeze countdown after this much idle */
/* being idle for a whole breaktime counts as a break already taken */
static const int idlecredit  =       1;

/* appearance of the break overlay */
static const char *fontbig   = "Noto Sans:size=80:bold";
static const char *fontmid   = "Noto Sans:size=20";
static const char *fontsmall = "Noto Sans:size=13";

static const char *colbg     = "#282828"; /* same gruvbox palette as dwm */
static const char *colfg     = "#ebdbb2";
static const char *colaccent = "#8ec07c";
static const char *colmuted  = "#928374";

static const double opacity  = 0.96; /* 1.0 = opaque; needs a compositor */
static const int barwidth    = 420;  /* progress bar width in pixels */
static const int barheight   = 6;

/* overlay texts */
static const char *breaktitle = "Перерыв — вставай из-за стола";
static const char *breakhint  = "Esc — пропустить   ·   p — отложить на 5 минут";

/* Exercises are shown one per break, in order, so the whole complex gets
 * covered over a working day.  Neck-and-shoulder work comes first: it is what
 * a day at the laptop actually needs.  Do the complex 2-4 times a day. */
static const Tip tips[] = {
	{ "Подбородок назад (chin tuck)",
	  "Смотри прямо, голову не опускай. Медленно отведи подбородок назад, как будто "
	  "делаешь «двойной подбородок». Задержись 3–5 секунд и расслабься. "
	  "8–10 повторений. Это разгружает позу «голова вперёд»." },
	{ "Повороты головы",
	  "Медленно поверни голову вправо до комфортного предела, вернись, затем влево. "
	  "Через боль не тянуть. По 5–8 раз в каждую сторону." },
	{ "Наклоны: ухо к плечу",
	  "Плечи оставь на месте. Медленно наклони голову вправо, затем влево. Должно быть "
	  "лёгкое растяжение сбоку шеи, а не боль. По 5 раз." },
	{ "Растяжка верхней трапеции",
	  "Наклони голову вправо, правой рукой совсем немного добавь веса. Левое плечо тяни "
	  "вниз. 20–30 секунд, затем другая сторона. По 2 раза." },
	{ "Растяжка мышцы, идущей к лопатке",
	  "Поверни голову на 45° вправо и посмотри вниз, будто смотришь в правый карман. "
	  "Очень мягко потяни голову рукой вниз — растяжение сзади-сбоку шеи. "
	  "20–30 секунд, затем другая сторона." },
	{ "Лопатки назад",
	  "Сидя или стоя расправь плечи и сведи лопатки немного назад и вниз, будто держишь "
	  "между ними карандаш. 5 секунд × 10 раз. За компьютером это часто полезнее, "
	  "чем разминать саму шею." },
	{ "Встань и пройдись",
	  "Пройди по квартире, налей стакан воды. Смена позы важнее любой растяжки: "
	  "плечи назад, лопатки вместе, шаг ровный." },
	{ "Отдых для глаз",
	  "Смотри в окно на дальний объект 20 секунд и поморгай — правило 20-20-20. "
	  "Заодно потянись всем телом вверх, как после сна, три раза." },
};

/* status line exported for the dwm status script (see README) */
static const char *statusfile   = "/tmp/pauzer";
static const char *pidfile      = "/tmp/pauzer.pid";
static const char *statuswork   = "🧘%dm";     /* minutes left until a break */
static const char *statusfrozen = "🧘%dm⏸";    /* countdown frozen: you are away */
static const char *statusbreak  = "☕%d:%02d";  /* break time left */
static const char *statusoff    = "🧘off";     /* timer paused by hand */

/* shell commands spawned on events; NULL disables one */
static const char *cmdbarrefresh = "refbar";
static const char *cmdwarn = "notify-send -a pauzer -u normal -t 10000 "
	"'🧘 Перерыв через минуту' 'Доводи мысль до точки и вставай.'";
static const char *cmdbreakstart = "paplay /usr/share/sounds/freedesktop/stereo/complete.oga";
static const char *cmdbreakend = "notify-send -a pauzer -u low -t 5000 "
	"'✅ Перерыв закончен' 'Следующий через 40 минут.' ; "
	"paplay /usr/share/sounds/freedesktop/stereo/message-new-instant.oga";
