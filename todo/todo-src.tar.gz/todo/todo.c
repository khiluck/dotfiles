/* See LICENSE file for copyright and license details.
 *
 * todo - a minimal task list for dwm.
 *
 * The list is a plain Markdown file: every line shaped like "- [ ] text" is a
 * task, every other line is kept verbatim, so headings and free notes written
 * in an editor survive a round trip.  Each change is written back immediately
 * through a temporary file and rename(2), which keeps the file consistent even
 * if the program dies mid-write, and makes the list safe to keep in git or to
 * mirror with unison.
 *
 * The window is an ordinary managed window advertising itself as a dialog, so
 * a window manager floats it without needing a rule.
 */
#include <errno.h>
#include <locale.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/Xft/Xft.h>
#ifdef XINERAMA
#include <X11/extensions/Xinerama.h>
#endif /* XINERAMA */

#define LEN(X)          (sizeof (X) / sizeof *(X))
#define MAX(A, B)       ((A) > (B) ? (A) : (B))
#define MIN(A, B)       ((A) < (B) ? (A) : (B))
#define INPUTMAX        512

typedef struct {
	char *text;             /* task text, or the whole line when raw */
	int done;               /* [x] rather than [ ] */
	int raw;                /* not a task: kept and shown as is */
	int indent;             /* leading spaces, so nesting survives */
} Item;

enum { ModeList, ModeAdd, ModeEdit };

#include "config.h"

static Display *dpy;
static int screen;
static Window root, win;
static Visual *visual;
static Colormap cmap;
static int depth, sw, sh;
static GC gc;
static Pixmap pm;
static XftDraw *draw;
static XIM xim;
static XIC xic;
static Atom netwmopacity, netwmwindowtype, netwmwindowtypedialog, wmdelete, wmprotocols;

static XftFont *fonts[LEN(fontnames)];
static int nfonts;
static XftColor cfg, cbg, caccent, cmuted;

static char *path;              /* expanded todofile */
static Item *items;
static int nitems;
static time_t filetime;         /* mtime of what we last read or wrote */

static int cur;                 /* cursor: index into items */
static int first;               /* first visible row */
static int rows;                /* visible task rows */
static int winw, winh;
static int mode = ModeList;
static char input[INPUTMAX];
static int inputlen;
static char message[256];       /* shown instead of the hint when set */
static int running = 1;

static void
die(const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	va_end(ap);
	fputc('\n', stderr);
	exit(1);
}

static void *
ecalloc(size_t n, size_t size)
{
	void *p;

	if (!(p = calloc(n, size)))
		die("todo: calloc: %s", strerror(errno));
	return p;
}

static char *
estrdup(const char *s)
{
	char *p;

	if (!(p = strdup(s)))
		die("todo: strdup: %s", strerror(errno));
	return p;
}

/* decode one utf-8 sequence, store the codepoint, return its byte length */
static int
utf8decode(const char *s, long *cp)
{
	static const unsigned char lens[] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 4 };
	const unsigned char *u = (const unsigned char *)s;
	int len = lens[*u >> 4], i;

	*cp = len == 1 ? *u : *u & (0x7f >> len);
	for (i = 1; i < len; i++) {
		if ((u[i] & 0xc0) != 0x80) { /* truncated: treat the lead byte alone */
			*cp = *u;
			return 1;
		}
		*cp = (*cp << 6) | (u[i] & 0x3f);
	}
	return len;
}

/* first font covering cp, falling back to the primary one */
static XftFont *
fontfor(long cp)
{
	int i;

	for (i = 1; i < nfonts; i++)
		if (XftCharExists(dpy, fonts[i], (FcChar32)cp) &&
		    !XftCharExists(dpy, fonts[0], (FcChar32)cp))
			return fonts[i];
	return fonts[0];
}

/* draw s at baseline y and return the x after it; d == NULL only measures */
static int
drawtext(XftDraw *d, XftColor *col, int x, int y, const char *s)
{
	const char *p = s, *start = s;
	XftFont *runfont = NULL, *f;
	XGlyphInfo ext;
	long cp;
	int len;

	while (*p) {
		len = utf8decode(p, &cp);
		f = fontfor(cp);
		if (!runfont) {
			runfont = f;
			start = p;
		} else if (f != runfont) {
			XftTextExtentsUtf8(dpy, runfont, (FcChar8 *)start, p - start, &ext);
			if (d)
				XftDrawStringUtf8(d, col, runfont, x, y, (FcChar8 *)start, p - start);
			x += ext.xOff;
			runfont = f;
			start = p;
		}
		p += len;
	}
	if (runfont && p > start) {
		XftTextExtentsUtf8(dpy, runfont, (FcChar8 *)start, p - start, &ext);
		if (d)
			XftDrawStringUtf8(d, col, runfont, x, y, (FcChar8 *)start, p - start);
		x += ext.xOff;
	}
	return x;
}

static char *
expandpath(const char *p)
{
	const char *home;
	char *out;
	size_t n;

	if (strncmp(p, "~/", 2) != 0)
		return estrdup(p);
	if (!(home = getenv("HOME")))
		die("todo: HOME is not set");
	n = strlen(home) + strlen(p);
	out = ecalloc(n, 1);
	snprintf(out, n, "%s%s", home, p + 1);
	return out;
}

static void
freeitems(void)
{
	int i;

	for (i = 0; i < nitems; i++)
		free(items[i].text);
	free(items);
	items = NULL;
	nitems = 0;
}

static Item *
pushitem(void)
{
	items = realloc(items, (nitems + 1) * sizeof *items);
	if (!items)
		die("todo: realloc: %s", strerror(errno));
	memset(&items[nitems], 0, sizeof *items);
	return &items[nitems++];
}

/* "  - [x] text" -> task; anything else is kept as a raw line */
static void
parseline(char *line)
{
	Item *it = pushitem();
	char *p = line;
	int indent = 0;

	while (*p == ' ' || *p == '\t') {
		indent += *p == '\t' ? 4 : 1;
		p++;
	}
	if ((p[0] == '-' || p[0] == '*') && p[1] == ' ' && p[2] == '[' &&
	    (p[3] == ' ' || p[3] == 'x' || p[3] == 'X') && p[4] == ']' &&
	    (p[5] == ' ' || p[5] == '\0')) {
		it->done = p[3] != ' ';
		it->indent = indent;
		it->text = estrdup(p[5] == ' ' ? p + 6 : "");
		return;
	}
	it->raw = 1;
	it->text = estrdup(line);
}

static void
load(void)
{
	FILE *f;
	struct stat st;
	char *line = NULL;
	size_t sz = 0;
	ssize_t len;

	freeitems();
	if (!(f = fopen(path, "r"))) {
		if (errno != ENOENT)
			snprintf(message, sizeof message, "не читается %s: %s", path, strerror(errno));
		if (filehead && *filehead) {
			parseline((char *)filehead);
			parseline("");
		}
		filetime = 0;
		return;
	}
	while ((len = getline(&line, &sz, f)) != -1) {
		while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r'))
			line[--len] = '\0';
		parseline(line);
	}
	free(line);
	fclose(f);
	filetime = stat(path, &st) == 0 ? st.st_mtime : 0;
}

/* write through a temporary file so the list is never left half-written */
static void
save(void)
{
	char tmp[4096];
	struct stat st;
	FILE *f;
	int i;

	snprintf(tmp, sizeof tmp, "%s.tmp", path);
	if (!(f = fopen(tmp, "w"))) {
		snprintf(message, sizeof message, "не сохранить: %s", strerror(errno));
		return;
	}
	for (i = 0; i < nitems; i++) {
		if (items[i].raw)
			fprintf(f, "%s\n", items[i].text);
		else
			fprintf(f, "%*s- [%c] %s\n", items[i].indent, "",
			        items[i].done ? 'x' : ' ', items[i].text);
	}
	if (fflush(f) != 0 || fsync(fileno(f)) != 0) {
		snprintf(message, sizeof message, "не сохранить: %s", strerror(errno));
		fclose(f);
		unlink(tmp);
		return;
	}
	fclose(f);
	if (rename(tmp, path) != 0) {
		snprintf(message, sizeof message, "не переименовать: %s", strerror(errno));
		unlink(tmp);
		return;
	}
	filetime = stat(path, &st) == 0 ? st.st_mtime : 0;
	message[0] = '\0';
}

static int
istask(int i)
{
	return i >= 0 && i < nitems && !items[i].raw;
}

/* move the cursor to the next task in direction dir, staying put if none */
static void
movecursor(int dir)
{
	int i;

	for (i = cur + dir; i >= 0 && i < nitems; i += dir) {
		if (istask(i)) {
			cur = i;
			return;
		}
	}
}

static void
firsttask(int fromend)
{
	int i;

	for (i = fromend ? nitems - 1 : 0; i >= 0 && i < nitems; i += fromend ? -1 : 1) {
		if (istask(i)) {
			cur = i;
			return;
		}
	}
}

/* pick the file up again if something else changed it while we were away */
static void
reloadifchanged(void)
{
	struct stat st;

	if (stat(path, &st) != 0 || st.st_mtime == filetime)
		return;
	load();
	cur = MIN(cur, MAX(nitems - 1, 0));
	if (!istask(cur))
		firsttask(0);
	first = 0;
}

static void
toggle(void)
{
	if (!istask(cur))
		return;
	items[cur].done = !items[cur].done;
	save();
}

static void
delitem(void)
{
	if (!istask(cur))
		return;
	free(items[cur].text);
	memmove(&items[cur], &items[cur + 1], (nitems - cur - 1) * sizeof *items);
	nitems--;
	if (cur >= nitems)
		cur = MAX(nitems - 1, 0);
	if (!istask(cur))
		movecursor(-1);
	save();
}

/* swap the current task with the next task in direction dir */
static void
moveitem(int dir)
{
	Item t;
	int i;

	if (!istask(cur))
		return;
	for (i = cur + dir; i >= 0 && i < nitems; i += dir) {
		if (!istask(i))
			continue;
		t = items[cur];
		items[cur] = items[i];
		items[i] = t;
		cur = i;
		save();
		return;
	}
}

static void
delcompleted(void)
{
	int i, n = 0;

	for (i = 0; i < nitems; i++) {
		if (istask(i) && items[i].done) {
			free(items[i].text);
			continue;
		}
		items[n++] = items[i];
	}
	if (n == nitems)
		return;
	nitems = n;
	cur = MIN(cur, MAX(nitems - 1, 0));
	if (!istask(cur))
		movecursor(-1);
	save();
}

static void
commitinput(void)
{
	Item *it;
	int i;

	if (!inputlen) {
		mode = ModeList;
		return;
	}
	if (mode == ModeEdit && istask(cur)) {
		free(items[cur].text);
		items[cur].text = estrdup(input);
	} else {
		it = pushitem();
		it->text = estrdup(input);
		/* a new task goes right after the last one, before trailing notes */
		for (i = nitems - 2; i >= 0; i--) {
			if (istask(i))
				break;
		}
		if (i >= 0 && i < nitems - 2) {
			Item t = items[nitems - 1];
			memmove(&items[i + 2], &items[i + 1], (nitems - i - 2) * sizeof *items);
			items[i + 1] = t;
			cur = i + 1;
		} else {
			cur = nitems - 1;
		}
	}
	mode = ModeList;
	save();
}

static void
countitems(int *left, int *done)
{
	int i;

	*left = *done = 0;
	for (i = 0; i < nitems; i++) {
		if (!istask(i))
			continue;
		if (items[i].done)
			(*done)++;
		else
			(*left)++;
	}
}

static void
redraw(void)
{
	char head[256];
	const char *prompt;
	int i, y, x, left, done, textleft = padding + drawtext(NULL, NULL, 0, 0, "[x] ");

	XSetForeground(dpy, gc, cbg.pixel);
	XFillRectangle(dpy, pm, gc, 0, 0, winw, winh);

	countitems(&left, &done);
	snprintf(head, sizeof head, "%s — осталось %d, выполнено %d", wintitle, left, done);
	y = padding + fonts[0]->ascent;
	drawtext(draw, &cfg, padding, y, head);

	/* keep the cursor inside the visible window */
	if (cur < first)
		first = cur;
	if (cur >= first + rows)
		first = cur - rows + 1;

	y = padding + lineheight;
	for (i = first; i < nitems && i < first + rows; i++) {
		int base = y + (lineheight - fonts[0]->height) / 2 + fonts[0]->ascent;
		XftColor *col = items[i].raw || items[i].done ? &cmuted : &cfg;

		if (i == cur && mode == ModeList && istask(cur)) {
			XSetForeground(dpy, gc, caccent.pixel);
			XFillRectangle(dpy, pm, gc, padding / 2, y, winw - padding, lineheight);
			col = &cbg;
		}
		if (items[i].raw) {
			drawtext(draw, col, padding, base, items[i].text);
		} else {
			x = padding + items[i].indent * fonts[0]->max_advance_width / 2;
			drawtext(draw, col, x, base, items[i].done ? "[x]" : "[ ]");
			x = drawtext(draw, col, textleft + items[i].indent *
			             fonts[0]->max_advance_width / 2, base, items[i].text);
			if (items[i].done && strikedone) {
				XSetForeground(dpy, gc, col->pixel);
				XFillRectangle(dpy, pm, gc, textleft, base - fonts[0]->ascent / 3,
				               x - textleft, 1);
			}
		}
		y += lineheight;
	}
	if (!left && !done)
		drawtext(draw, &cmuted, padding,
		         padding + lineheight * (1 + nitems - first) + fonts[0]->ascent, emptyhint);

	/* bottom line: either the text being typed or the key hints */
	XSetForeground(dpy, gc, cmuted.pixel);
	XFillRectangle(dpy, pm, gc, padding, winh - padding - lineheight, winw - padding * 2, 1);
	y = winh - padding - fonts[0]->descent;
	if (mode == ModeList) {
		drawtext(draw, &cmuted, padding, y, message[0] ? message : hint);
	} else {
		prompt = mode == ModeAdd ? inputadd : inputedit;
		x = drawtext(draw, &caccent, padding, y, prompt);
		x = drawtext(draw, &cfg, x, y, input);
		XSetForeground(dpy, gc, cfg.pixel);
		XFillRectangle(dpy, pm, gc, x + 1, y - fonts[0]->ascent, 2, fonts[0]->height);
	}

	XCopyArea(dpy, pm, win, gc, 0, 0, winw, winh, 0, 0);
	XFlush(dpy);
}

/* grow or shrink the window to the number of rows we actually have */
/* an empty list needs one extra row for the "list is empty" hint */
static int
wantrows(void)
{
	int left, done;

	countitems(&left, &done);
	return MIN(MAX(nitems + (left || done ? 0 : 1), 1), maxrows);
}

static void
fitwindow(void)
{
	int want = wantrows();
	int h = padding * 2 + lineheight * (want + 2);

	rows = want;
	if (h == winh)
		return;
	winh = h;
	XResizeWindow(dpy, win, winw, winh);
	XFreePixmap(dpy, pm);
	pm = XCreatePixmap(dpy, root, winw, winh, depth);
	XftDrawChange(draw, pm);
}

/* Keysym for a COMMAND key, independent of the active keyboard layout.
 * With a Latin layout the first-group keysym is already a-z. With a Cyrillic
 * layout the ru/ua maps here fully replace us (no Latin group at all), so a
 * letter key yields Cyrillic_*; then we map the physical evdev keycode to its
 * Latin letter. Non-letter keys (Return/Escape/arrows/space) are the same in
 * every layout and pass through unchanged. Letters are returned lowercase; the
 * command switch reads ShiftMask itself. */
static KeySym
cmdksym(XKeyEvent *e)
{
	static const struct { unsigned int kc; KeySym ks; } map[] = {
		{ 24, XK_q }, { 25, XK_w }, { 26, XK_e }, { 27, XK_r }, { 28, XK_t },
		{ 29, XK_y }, { 30, XK_u }, { 31, XK_i }, { 32, XK_o }, { 33, XK_p },
		{ 38, XK_a }, { 39, XK_s }, { 40, XK_d }, { 41, XK_f }, { 42, XK_g },
		{ 43, XK_h }, { 44, XK_j }, { 45, XK_k }, { 46, XK_l },
		{ 52, XK_z }, { 53, XK_x }, { 54, XK_c }, { 55, XK_v }, { 56, XK_b },
		{ 57, XK_n }, { 58, XK_m },
	};
	KeySym ks = XLookupKeysym(e, 0);
	size_t i;

	if (ks >= XK_a && ks <= XK_z)
		return ks;                     /* Latin layout: use as is */
	if (ks >= XK_A && ks <= XK_Z)
		return ks - (XK_A - XK_a);     /* Latin, shifted level: lowercase it */
	for (i = 0; i < LEN(map); i++)     /* non-Latin: map by physical position */
		if (map[i].kc == e->keycode)
			return map[i].ks;
	return ks;                         /* non-letter keys: layout-independent */
}

static void
keypress(XKeyEvent *e)
{
	char buf[64];
	KeySym ks;
	Status status;
	int len;

	if (mode != ModeList) {
		/* typing text: honour the active keyboard layout */
		len = xic ? Xutf8LookupString(xic, e, buf, sizeof buf - 1, &ks, &status)
		          : XLookupString(e, buf, sizeof buf - 1, &ks, NULL);
		switch (ks) {
		case XK_Escape:
			mode = ModeList;
			return;
		case XK_Return:
		case XK_KP_Enter:
			commitinput();
			return;
		case XK_BackSpace:
			while (inputlen > 0 && (input[--inputlen] & 0xc0) == 0x80)
				; /* step back over a whole utf-8 sequence */
			input[inputlen] = '\0';
			return;
		}
		if (len > 0 && (unsigned char)buf[0] >= 0x20 && inputlen + len < INPUTMAX) {
			memcpy(input + inputlen, buf, len);
			inputlen += len;
			input[inputlen] = '\0';
		}
		return;
	}

	/* commands: layout-independent keysym (works under ru/ua too) */
	ks = cmdksym(e);
	switch (ks) {
	case XK_q:
	case XK_Escape:
		running = 0;
		break;
	case XK_j:
	case XK_Down:
		if (e->state & ShiftMask)
			moveitem(1);
		else
			movecursor(1);
		break;
	case XK_k:
	case XK_Up:
		if (e->state & ShiftMask)
			moveitem(-1);
		else
			movecursor(-1);
		break;
	case XK_g:
	case XK_Home:
		firsttask(e->state & ShiftMask);
		break;
	case XK_G:
	case XK_End:
		firsttask(1);
		break;
	case XK_space:
	case XK_Return:
	case XK_KP_Enter:
		toggle();
		break;
	case XK_a:
	case XK_i:
		mode = ModeAdd;
		input[0] = '\0';
		inputlen = 0;
		break;
	case XK_e:
		if (!istask(cur))
			break;
		mode = ModeEdit;
		snprintf(input, sizeof input, "%s", items[cur].text);
		inputlen = strlen(input);
		break;
	case XK_d:
		if (e->state & ShiftMask)
			delitem();
		break;
	case XK_c:
		if (e->state & ShiftMask)
			delcompleted();
		break;
	}
	fitwindow();
}

static void
setupfonts(void)
{
	size_t i;

	for (i = 0; i < LEN(fontnames); i++) {
		if ((fonts[nfonts] = XftFontOpenName(dpy, screen, fontnames[i])))
			nfonts++;
		else
			fprintf(stderr, "todo: cannot load font %s\n", fontnames[i]);
	}
	if (!nfonts)
		die("todo: no usable font");
}

static void
setup(void)
{
	XSetWindowAttributes wa;
	XClassHint ch = { "todo", "todo" };
	XSizeHints *sh_;
	unsigned long op;
	int x, y, di;
	unsigned int du;
	Window dw;

	if (!(dpy = XOpenDisplay(NULL)))
		die("todo: cannot open display");
	screen = DefaultScreen(dpy);
	root = RootWindow(dpy, screen);
	visual = DefaultVisual(dpy, screen);
	cmap = DefaultColormap(dpy, screen);
	depth = DefaultDepth(dpy, screen);
	sw = DisplayWidth(dpy, screen);
	sh = DisplayHeight(dpy, screen);

	setupfonts();
	if (!XftColorAllocName(dpy, visual, cmap, colfg, &cfg) ||
	    !XftColorAllocName(dpy, visual, cmap, colbg, &cbg) ||
	    !XftColorAllocName(dpy, visual, cmap, colaccent, &caccent) ||
	    !XftColorAllocName(dpy, visual, cmap, colmuted, &cmuted))
		die("todo: cannot allocate colors");

	winw = MAX(winwidth, drawtext(NULL, NULL, 0, 0, hint) + padding * 2);
	rows = wantrows();
	winh = padding * 2 + lineheight * (rows + 2);

	/* centre on the monitor holding the pointer */
	x = (sw - winw) / 2;
	y = (sh - winh) / 2;
#ifdef XINERAMA
	if (XineramaIsActive(dpy)) {
		XineramaScreenInfo *info;
		int i, n;

		if ((info = XineramaQueryScreens(dpy, &n))) {
			if (XQueryPointer(dpy, root, &dw, &dw, &x, &y, &di, &di, &du)) {
				for (i = 0; i < n; i++) {
					if (x >= info[i].x_org && x < info[i].x_org + info[i].width &&
					    y >= info[i].y_org && y < info[i].y_org + info[i].height)
						break;
				}
				if (i == n)
					i = 0;
				x = info[i].x_org + (info[i].width - winw) / 2;
				y = info[i].y_org + (info[i].height - winh) / 2;
			}
			XFree(info);
		}
	}
#endif /* XINERAMA */

	wa.background_pixel = cbg.pixel;
	wa.event_mask = ExposureMask | KeyPressMask | StructureNotifyMask | FocusChangeMask;
	win = XCreateWindow(dpy, root, x, y, winw, winh, 0, depth, InputOutput, visual,
	                    CWBackPixel | CWEventMask, &wa);
	gc = XCreateGC(dpy, win, 0, NULL);
	pm = XCreatePixmap(dpy, root, winw, winh, depth);
	draw = XftDrawCreate(dpy, pm, visual, cmap);

	XSetClassHint(dpy, win, &ch);
	XStoreName(dpy, win, wintitle);
	Xutf8SetWMProperties(dpy, win, wintitle, wintitle, NULL, 0, NULL, NULL, NULL);

	/* a dialog gets floated by the window manager without needing a rule */
	netwmwindowtype = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE", False);
	netwmwindowtypedialog = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE_DIALOG", False);
	XChangeProperty(dpy, win, netwmwindowtype, XA_ATOM, 32, PropModeReplace,
	                (unsigned char *)&netwmwindowtypedialog, 1);
	netwmopacity = XInternAtom(dpy, "_NET_WM_WINDOW_OPACITY", False);
	op = (unsigned long)(0xffffffffU * (opacity < 0 ? 0 : opacity > 1 ? 1 : opacity));
	XChangeProperty(dpy, win, netwmopacity, XA_CARDINAL, 32, PropModeReplace,
	                (unsigned char *)&op, 1);
	wmprotocols = XInternAtom(dpy, "WM_PROTOCOLS", False);
	wmdelete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
	XSetWMProtocols(dpy, win, &wmdelete, 1);

	if ((sh_ = XAllocSizeHints())) {
		sh_->flags = PPosition;
		XSetWMNormalHints(dpy, win, sh_);
		XFree(sh_);
	}

	if ((xim = XOpenIM(dpy, NULL, NULL, NULL)))
		xic = XCreateIC(xim, XNInputStyle, XIMPreeditNothing | XIMStatusNothing,
		                XNClientWindow, win, XNFocusWindow, win, NULL);

	XMapRaised(dpy, win);
}

static void
cleanup(void)
{
	int i;

	if (xic)
		XDestroyIC(xic);
	if (xim)
		XCloseIM(xim);
	XftDrawDestroy(draw);
	XFreePixmap(dpy, pm);
	XFreeGC(dpy, gc);
	XDestroyWindow(dpy, win);
	for (i = 0; i < nfonts; i++)
		XftFontClose(dpy, fonts[i]);
	XftColorFree(dpy, visual, cmap, &cfg);
	XftColorFree(dpy, visual, cmap, &cbg);
	XftColorFree(dpy, visual, cmap, &caccent);
	XftColorFree(dpy, visual, cmap, &cmuted);
	XCloseDisplay(dpy);
	freeitems();
	free(path);
}

static void
run(void)
{
	XEvent ev;

	while (running && !XNextEvent(dpy, &ev)) {
		if (XFilterEvent(&ev, win))
			continue;
		switch (ev.type) {
		case Expose:
			if (ev.xexpose.count == 0)
				redraw();
			break;
		case KeyPress:
			keypress(&ev.xkey);
			if (running)
				redraw();
			break;
		case FocusIn:
			if (xic)
				XSetICFocus(xic);
			reloadifchanged();
			fitwindow();
			redraw();
			break;
		case FocusOut:
			if (xic)
				XUnsetICFocus(xic);
			break;
		case ConfigureNotify:
			if (ev.xconfigure.width != winw || ev.xconfigure.height != winh) {
				winw = ev.xconfigure.width;
				winh = ev.xconfigure.height;
				rows = MAX((winh - padding * 2) / lineheight - 2, 1);
				XFreePixmap(dpy, pm);
				pm = XCreatePixmap(dpy, root, winw, winh, depth);
				XftDrawChange(draw, pm);
				redraw();
			}
			break;
		case ClientMessage:
			if (ev.xclient.message_type == wmprotocols &&
			    (Atom)ev.xclient.data.l[0] == wmdelete)
				running = 0;
			break;
		}
	}
}

static void
usage(void)
{
	die("usage: todo [-v] [-f file]");
}

int
main(int argc, char *argv[])
{
	const char *file = todofile;
	int i;

	for (i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "-v")) {
			puts("todo-"VERSION);
			return 0;
		} else if (!strcmp(argv[i], "-f")) {
			if (++i >= argc)
				usage();
			file = argv[i];
		} else {
			usage();
		}
	}

	if (!setlocale(LC_CTYPE, "") || !XSupportsLocale())
		fputs("todo: locale not supported, typing may be limited\n", stderr);
	XSetLocaleModifiers("");

	path = expandpath(file);
	load();
	firsttask(0);
	setup();
	run();
	cleanup();
	return 0;
}
